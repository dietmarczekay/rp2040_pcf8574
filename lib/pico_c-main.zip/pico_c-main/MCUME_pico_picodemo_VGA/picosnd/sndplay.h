extern void snd_Init(void);
extern void snd_Step(void);
extern void snd_Start(char * filename);
extern void snd_Input(int bClick);
