#include "platform_config.h"
#include "iopins.h"

//#define ST7789         1
//#define ILI9341        1

#define TFT_STATICFB   1
#define TFT_LINEARINT  1
#define LINEARINT_HACK 1


