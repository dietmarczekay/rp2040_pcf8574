#pragma once
#include "ff.h"
const char *FRESULT_str(FRESULT i);