﻿#include "main.h"   //Examples

int main(void)
{
    while(1) {
        lcd_test();
    }
    return 0;
}
