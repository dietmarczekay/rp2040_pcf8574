# pico_c
random set of raspberry pi pico device related C code
