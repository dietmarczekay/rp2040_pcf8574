﻿#include "main.h"   //sdcard_test

int main(void)
{
//    while(1) {
    //just execute this the once
    //we only want to be able to test we can get access to the SDCard
        sdcard_test();
//    }
    return 0;
}
